package com.operation.ATDevCRODAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtDevCrodapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
