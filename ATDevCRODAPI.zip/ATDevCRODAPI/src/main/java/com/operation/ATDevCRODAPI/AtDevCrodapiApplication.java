package com.operation.ATDevCRODAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtDevCrodapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtDevCrodapiApplication.class, args);
	}

}
